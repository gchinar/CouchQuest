CouchQuest - SEZG583 Scalable Services Assignment
Student: Chinar Goel | 2025MT03125

CONTENTS
2025MT03125_CouchQuest.pdf - Complete 43-page report with diagrams and evidence.
2025MT03125_CouchQuest_Demo.mp4 - Captioned live-screen demonstration (87 seconds).
2025MT03125_CouchQuest_Postman.json - Postman evidence collection; run in order.
source/ - Both service source snapshots, tests, Dockerfiles, deployment scripts,
          Kubernetes manifests, CI workflows and text/JSON deployment evidence.

REPOSITORIES
https://github.com/gchinar/CouchQuest
https://github.com/gchinar/couchquest-catalog
https://github.com/gchinar/couchquest-session

RUNNING THE SOLUTION
Follow source/README.md and the individual service README files.
Use source/deployment/.env.example as a template for local demo configuration.
The two services are maintained in independent repositories; source copies are
included for convenient assessment, without Git history or build caches.

POSTMAN
The evidence collection defaults to Kubernetes: Catalog port 18001, Session 18002.
For Docker Compose, change catalog_url to http://127.0.0.1:8001 and session_url to
http://127.0.0.1:8002. Creation-response scripts save IDs for subsequent requests.

HPA
The demonstrated configuration is source/deployment/session-hpa.yaml
(Session only, CPU target 70%, 1-3 replicas). Enable Minikube metrics-server first.
The original hpa.yaml is an alternative example targeting both API services;
do not apply both alternatives together.

MEDIA
Images and video have been compressed to meet the total ZIP size limit.
The report retains all pages, selectable text and links. Screenshots and posters
are embedded in the report; duplicate full-resolution image files are omitted.
The video shows selected API responses, repositories, CI and Kubernetes views;
it is not a recording of every operation or of a new autoscaling load test.
Localhost links require the deployed local environment and active port forwards.
